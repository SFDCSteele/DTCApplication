#!/bin/bash
clear

#javac -cp ./lib/\* force-enterprise-api-master/src/main/java/com/sforce/soap/enterprise/sobject/*.java
#javac -cp ./lib/\* force-enterprise-api-master/src/main/java/com/sforce/soap/enterprise/*.java


#javac -cp ./lib/\* force-enterprise-api-master/src/test/java/GenerateSourceFromWSDL.java
javac -cp ./lib/\* salesforce_rest/CICDRestClient.java
javac -cp ./lib/\* salesforce_rest/CICDRestClientV2.java

#javac  -g -cp ./lib/\*:force-enterprise-api-master/src/main/java/com/sforce/soap/enterprise:force-enterprise-api-master/src/main/java/com/sforce/soap/enterprise/sobject \
#     -sourcepath force-enterprise-api-master/src/main/java/com/sforce/soap/enterprise:force-enterprise-api-master/src/main/java/com/sforce/soap/enterprise/sobject \
#      -d force-enterprise-api-master/target \
#      force-enterprise-api-master/src/main/java/com/sforce/soap/enterprise/sobject/*.java 

#javac -cp ./lib/\* salesforce_deploy/CICDDeployClient.java



if [ "$1" = "LIST" ]
then
    echo "enter the class you are looking for:"
    read inpt
    FILES=./lib/*.jar
    for f in $FILES
    do
    echo "Processing $f file..."
    # take action on each file. $f store current file name
    #ls -al $f
    jar -tf $f 
    #| grep $inpt
    echo "---------------------"
    echo "press return to continue"
    read inpt
    done
fi
