clear
./buildjava.sh $1

#loadEnvironmentVars:BUILDSTATUS_VARS: CI_BUILD_URL value: https://app.codeship.com/projects/304537/builds/41591330
#loadEnvironmentVars:BUILDSTATUS_VARS: CI_BUILD_ID value: 41591330
#loadEnvironmentVars:BUILDSTATUS_VARS: CI_STATUS value: Initiated
#loadEnvironmentVars:BUILDSTATUS_VARS: CI_NAME value: codeship
#loadEnvironmentVars:BUILDSTATUS_VARS: CI_REPO_NAME value: department-of-veterans-affairs/va-salesforce-master
#loadEnvironmentVars:BUILDSTATUS_VARS: CI_COMMIT_ID value: c37c24f0e72aa741d87640b685f78832beaa32c5
#loadEnvironmentVars:BUILDSTATUS_VARS: CI_MESSAGE value: Merge branch \'VIEWS-ENH-000570\' of https://github.com/department-of-veterans-affairs/va-salesforce-master into VIEWS-ENH-000570
#loadEnvironmentVars:BUILDSTATUS_VARS: CI_COMMITTER_NAME value: John Preniczky
#loadEnvironmentVars:BUILDSTATUS_VARS: CI_BRANCH value: VIEWS-ENH-000570
#Build to be inserted:
#{"build": {"build_url":"https://app.codeship.com/projects/304537/builds/41591330","commit_url":"https://app.codeship.com/projects/304537/builds/41591330","project_id":41591330,"build_id":41591330,"status":"Initiated","project_name":"codeship","commit_id":"c37c24f0e72aa741d87640b685f78832beaa32c5","short_commit_id":"41591330","message":"Merge branch \'VIEWS-ENH-000570\' of https://github.com/department-of-veterans-affairs/va-salesforce-master into VIEWS-ENH-000570","committer":"John Preniczky","branch":"VIEWS-ENH-000570"}}
#Insertion unsuccessful. Status code returned is 500

# prod setup
export deployLocation=$REPO_LOCATION/deploy
export CICD_USERNAME=william.steele6@va.gov
export CICD_PASSWORD=Stay@ut1905Pdd3h8pFxdXDbFzTpbEOUQpXG
export CICD_LOGINURL=https://va.my.salesforce.com
export CICD_GRANTSERVICE=/services/oauth2/token?grant_type=password
export CICD_CLIENTID=3MVG9NEgrsZAHtHQL62sN9utlxUhNvyEGpKTtCwD9RRGV2TbRh2CVPCZxQwEpndHVM1BwkBjZ7FCrfFzwtbBH
export CICD_CLIENTSECRET=932A5DE093AEA071E4A05D55D30DBBCEFE8E6419B7E48E6DA9312B826AC8C6F5
# ctalbotva setup
export deployLocation=$REPO_LOCATION/deploy
export CICD_USERNAME=william.steele6@va.gov.ctalbotva
export CICD_PASSWORD=Stay@ut190811vv9IkHapK7wzvNeqquSFHRk
export CICD_LOGINURL=https://va--ctalbotva.my.salesforce.com
export CICD_GRANTSERVICE=/services/oauth2/token?grant_type=password
#
export envName=UAT
export CI_BUILD_URL=https://app.codeship.com/projects/304537/builds/41494671
export CI_BUILD_ID=41494703
export CI_STATUS=Initiated
#export CI_STATUS=Success
export CI_NAME=codeship/TESTING 
export CI_REPO_NAME=department-of-veterans-affairs/va-salesforce-master
export CI_COMMIT_ID=1e79be6f14c98da0cb5e3d81a3c32d07818d422a
export CI_MESSAGE="added Package.xml for ENH-000586"
export CI_MESSAGE="Merge pull request #1042 from department-of-veterans-affairs/Release_19.6.1

Deploy Release_19.6.1 to Staging"
export CI_COMMITTER_NAME="John Preniczky"
export CI_BRANCH="VIEWS-ENH-000586"

#java -cp ./lib/\*:. salesforce_rest.CICDRestClient buildStatus
java -cp ./lib/\*:. salesforce_rest.CICDRestClientV2  getSandboxName VAHD-ENH-000699
#cat setSystem
source setSystem
echo "deployToSIT=$deployToSIT"
echo "sitEnvName=$sitEnvName"
echo "============================================"
if [ "$deployToSIT" = "true" ]
then
    export envName=$sitEnvName
else
    export envName="ENTSD"
fi
java -cp ./lib/\*:. salesforce_rest.CICDRestClientV2  getEnvironmentDetails $envName
#cat setSystem
source setSystem
echo "envName=$envName"
echo "serverURL=$serverURL"
echo "username=$username"
echo "password=$password"
#java -cp ./lib/\*:. salesforce_rest.CICDRestClientV2 buildStatus
#java -cp ./lib/\*:. salesforce_rest.CICDRestClient  submitPackage /Users/williamsteele/VAWork/deployments/work/repo-VAHD-ENH-000602-3/src/build/Releases/Release_19.5.1/Package_VAHD-ENH-000602-3.xml
#java -cp ./lib/\*:. salesforce_rest.CICDRestClient  submitPackage /Users/williamsteele/VAWork/deployments/work/repo-Release_19.5.1/src/build/Releases/Release_19.5.1/Package_ALL.xml

export envName=ENTSD
export serverURL=https://va--ENTSD.my.salesforce.com
export username=william.steele6@va.gov.entsd
export password=Stay@ut1904lafnKJzSSJhGMbtA3BLN9iDh
export packageXML=Package_ALL.xml
export dev_branch=Release_19.5.1
export release_branch=$dev_branch
export check=false
export deployLocation=/Users/williamsteele/VAWork/deployments/work/deploy-$dev_branch
export repoLocation=/Users/williamsteele/VAWork/deployments/work/repo-$dev_branch
#the following variables are used to tell the script deploy and deploy_full where to find files it needs for the build
export deployFullLocation=/Users/williamsteele/VAWork/deployments/work/deploy-$dev_branch
export repoFullLocation=/Users/williamsteele/VAWork/deployments/work/repo-$dev_branch
#
export DEPLOY_USERNAME=william.steele6@va.gov.entsd
export DEPLOY_PASSWORD=Stay@ut1904lafnKJzSSJhGMbtA3BLN9iDh
export DEPLOY_LOGINURL=https://va--ENTSD.my.salesforce.com
export DEPLOY_ZIPFILE=/Users/williamsteele/VAWork/deployments/work/deploy-$dev_branch/zip
#

#ant -propertyfile test/build.properties -buildfile test/full_build.xml  execute-deploy

#echo "attempting to execute the GenerateSourceFromWSDL class...."
#cd ./force-enterprise-api-master/src/test/java
#ls -al
#java -cp ../../../../lib/\*:./java/\*:../resources/\*:. GenerateSourceFromWSDL
#java -cp ./lib/\*:. salesforce_deploy.CICDDeployClient

